package LEADS

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"onviz/DB"
)

type Lead struct {
	Id       string `json:"id,omitempty"`
	Title    string `json:"title,omitempty"`
	Link     string `json:"link,omitempty"`
	Status   string `json:"status,omitempty"`
	Assigned string `json:"assigned,omitempty"`
}

func LeadsAdd(w http.ResponseWriter, r *http.Request) {

	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {
			fmt.Println(err.Error())
			fmt.Println("error body close")
		}
	}(r.Body)
	if r.Method == "POST" {
		w.WriteHeader(http.StatusOK)
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		fmt.Println("error read body")
	}
	fmt.Println("BODY: ", string(body))
	var lead Lead

	err = json.Unmarshal(body, &lead)
	if err != nil {
		fmt.Println("error unmarshall")
		return
	}
	newData, err := json.Marshal(lead)
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println(string(newData))
	}
	fmt.Println("LEAD :", lead)

	fmt.Println("error lead collect")
	DB.LeadCollectToDb(lead.Id, lead.Title, lead.Link, lead.Status, lead.Assigned)
	fmt.Println("lead added")

}

func GetAllFromLead(db *sql.DB) {
	rows, err := db.Query("select * from lead")
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	products := []Lead{}

	for rows.Next() {
		p := Lead{}
		err := rows.Scan(&p.Id, &p.Title, &p.Link, &p.Status, &p.Assigned)
		if err != nil {
			fmt.Println(err)
			continue
		}
		products = append(products, p)
	}
	for _, p := range products {
		fmt.Println(p.Id, p.Title, p.Link, p.Status, p.Assigned)
	}
}

func GetLeads(w http.ResponseWriter, r *http.Request) {

	req, err := http.Get("https://onviz.bitrix24.ru/rest/13938/xldrq7vlqx5suw13/crm.lead.list")
	if err != nil {
		log.Println("Error http:post request to Bitrix24")
	}
	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {
			fmt.Println(err.Error())
			fmt.Println("error body close")
		}
	}(r.Body)

	body, err := io.ReadAll(req.Body)
	if err != nil {
		fmt.Println("error read body")
	}
	fmt.Println("BODY: ", string(body))

	//var lead Lead

	/*err = json.Unmarshal(body, &lead)
	if err != nil {
		fmt.Println("error unmarshall")
		return
	}
	newData, err := json.Marshal(lead)
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println(string(newData))
	}*/
}
