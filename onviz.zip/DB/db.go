package DB

import (
	"database/sql"
	"fmt"
	"log"
)

func LeadCollectToDb(id, title, link, status, assigned string) {
	db, err := ConnectToDb()

	result, err := db.Exec("insert into lead (id, title, link, status, assigned) values ($1, $2, $3, $4, $5)",
		id, title, link, status, assigned)
	if err != nil {
		fmt.Println("cant insert data to dbase")
		panic(err)
	}
	fmt.Println("rows inserted")
	fmt.Println(result.RowsAffected()) // количество добавленных строк
}

func ConnectToDb() (*sql.DB, error) {
	//connStr := "user=postgres password=postgres dbname=postgres sslmode=disable"

	connStr := "user=postgres password=postgres dbname=postgres sslmode=disable"
	db, err := sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal(err)
	}
	defer func(db *sql.DB) {
		err := db.Close()
		if err != nil {
			fmt.Println("err db close")
		}
	}(db)
	err = db.Ping()
	if err != nil {
		fmt.Println("db not pings")
		return nil, err
	}
	return db, nil
}
